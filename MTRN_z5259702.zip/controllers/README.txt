This code was written in vscode and tested on webots.
It consists of 6 controllers, one for each robot and one for the supervising director robot.
Furthermore there is a helper code file which provides a large portion of functions and classes to the controller files.
To run the code in webots all 6 controller files must be compiled.